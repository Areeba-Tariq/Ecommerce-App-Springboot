package com.jtspringproject.JtSpringProject.models;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CategoryTest {
    @Test
    void testSetId() {
        Category category = new Category();
        category.setId(1);
        category.setName("Name");
        int actualId = category.getId();
        assertEquals("Name", category.getName());
        assertEquals(1, actualId);
    }
}
